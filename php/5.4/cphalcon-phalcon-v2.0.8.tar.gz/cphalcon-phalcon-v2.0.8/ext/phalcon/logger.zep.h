
extern zend_class_entry *phalcon_logger_ce;

ZEPHIR_INIT_CLASS(Phalcon_Logger);

